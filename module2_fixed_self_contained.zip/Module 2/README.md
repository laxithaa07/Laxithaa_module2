# Module 2
All four applications are self-contained and include their CSS/JavaScript inside `index.html` so they work reliably when opened locally or hosted on GitHub Pages.
