
const screen=document.getElementById('screen'),small=document.getElementById('small');let exp='',done=false;
function show(){screen.textContent=exp||'0'}
function result(){try{let s=exp.replace(/%/g,'/100');if(!/^[0-9+\-*/.\s]+$/.test(s))throw Error();let r=Function('return ('+s+')')();if(!Number.isFinite(r))throw Error();small.textContent=exp+' =';exp=String(Number(r.toFixed(10)));done=true;show()}catch(e){small.textContent='Invalid calculation';screen.textContent='Error';exp=''}}
document.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{let k=b.dataset.k;if(k==='C'){exp='';small.textContent='Ready';done=false;show();return}if(k==='B'){exp=exp.slice(0,-1);show();return}if(k==='='){if(exp)result();return}if(done&&/[0-9.]/.test(k)){exp='';done=false}exp+=k;show()});show();
